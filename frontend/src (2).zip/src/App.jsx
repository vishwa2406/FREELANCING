import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { ToastProvider } from './context/ToastContext'
import ProtectedRoute from './components/ProtectedRoute'
import DashboardLayout from './layouts/DashboardLayout'

// Pages
import Login from './pages/Login'
import Register from './pages/Register'
import ForgotPassword from './pages/ForgotPassword'
import Dashboard from './pages/Dashboard'
import Courses from './pages/Courses'
import CourseDetail from './pages/CourseDetail'
import VideoPlayer from './pages/VideoPlayer'
import Quiz from './pages/Quiz'
import Jobs from './pages/Jobs'
import Progress from './pages/Progress'
import Mentors from './pages/Mentors'
import Profile from './pages/Profile'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            {/* Public */}
            <Route path="/login"          element={<Login />} />
            <Route path="/register"       element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />

            {/* Protected */}
            <Route element={<ProtectedRoute />}>
              <Route element={<DashboardLayout />}>
                <Route path="/"              element={<Navigate to="/dashboard" replace />} />
                <Route path="/dashboard"     element={<Dashboard />} />
                <Route path="/courses"       element={<Courses />} />
                <Route path="/courses/:id"   element={<CourseDetail />} />
                <Route path="/courses/:id/watch" element={<VideoPlayer />} />
                <Route path="/quiz/:id"      element={<Quiz />} />
                <Route path="/jobs"          element={<Jobs />} />
                <Route path="/progress"      element={<Progress />} />
                <Route path="/mentors"       element={<Mentors />} />
                <Route path="/profile"       element={<Profile />} />
              </Route>
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </AuthProvider>
  )
}