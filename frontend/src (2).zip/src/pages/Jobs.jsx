import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { jobAPI } from '../services/api'
import { useApi } from '../hooks/useApi'
import { useToast } from '../context/ToastContext'
import Badge from '../components/ui/Badge'
import Button from '../components/ui/Button'
import Modal from '../components/ui/Modal'
import { JobCardSkeleton } from '../components/ui/Skeleton'
import EmptyState from '../components/ui/EmptyState'

const types = ['all', 'full-time', 'part-time', 'internship', 'contract', 'remote']

export default function Jobs() {
  const { toast } = useToast()
  const [search, setSearch]   = useState('')
  const [type, setType]       = useState('all')
  const [location, setLocation] = useState('')
  const [page, setPage]       = useState(1)
  const [selected, setSelected] = useState(null)
  const [saved, setSaved]     = useState(new Set())

  const fetchFn = useCallback(
    () => jobAPI.list({ search: search || undefined, type: type !== 'all' ? type : undefined, location: location || undefined, page }),
    [search, type, location, page]
  )

  const { data, loading } = useApi(fetchFn, [search, type, location, page], { defaultData: { jobs: [], total: 0, pages: 1 } })
  const jobs = data?.jobs || []

  const handleSave = async (e, jobId) => {
    e.stopPropagation()
    try {
      await jobAPI.save(jobId)
      setSaved(prev => {
        const n = new Set(prev)
        n.has(jobId) ? n.delete(jobId) : n.add(jobId)
        return n
      })
      toast(saved.has(jobId) ? 'Removed from saved' : 'Job saved!', 'success')
    } catch {
      toast('Failed to save job', 'error')
    }
  }

  const typeColors = { 'full-time': 'success', 'part-time': 'warning', internship: 'brand', contract: 'danger', remote: 'default' }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-white">Job Board</h1>
        <p className="text-surface-400 text-sm mt-0.5">{data?.total || 0} opportunities available</p>
      </div>

      {/* Filters */}
      <div className="glass-dark rounded-2xl p-4 space-y-3">
        <div className="flex gap-3">
          <input placeholder="Search jobs, companies…" value={search}
            onChange={e => { setSearch(e.target.value); setPage(1) }}
            className="flex-1 bg-surface-800 border border-surface-700 hover:border-surface-600 focus:border-brand-500 rounded-xl px-3.5 py-2.5 text-sm text-surface-50 placeholder-surface-500 focus-ring transition-all" />
          <input placeholder="Location…" value={location}
            onChange={e => { setLocation(e.target.value); setPage(1) }}
            className="w-40 bg-surface-800 border border-surface-700 hover:border-surface-600 focus:border-brand-500 rounded-xl px-3.5 py-2.5 text-sm text-surface-50 placeholder-surface-500 focus-ring transition-all" />
        </div>
        <div className="flex flex-wrap gap-2">
          {types.map(t => (
            <button key={t} onClick={() => { setType(t); setPage(1) }}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-all capitalize ${type === t ? 'bg-brand-500 text-white' : 'bg-surface-800 text-surface-400 hover:bg-surface-700 hover:text-white'}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      {loading
        ? <div className="space-y-3">{[...Array(5)].map((_, i) => <JobCardSkeleton key={i} />)}</div>
        : jobs.length === 0
          ? <EmptyState title="No jobs found" description="Try different filters."
              icon={<svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01" /></svg>}
            />
          : (
            <div className="space-y-3">
              {jobs.map((job, i) => (
                <motion.div key={job._id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * .04 }}
                  whileHover={{ x: 2 }}
                  onClick={() => setSelected(job)}
                  className="glass-dark rounded-2xl p-5 cursor-pointer border border-transparent hover:border-brand-500/20 transition-all group">
                  <div className="flex items-start gap-4">
                    {/* Company logo placeholder */}
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-surface-700 to-surface-600 flex items-center justify-center text-lg font-bold text-surface-300 shrink-0">
                      {job.company?.[0] || '?'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-semibold text-white text-sm group-hover:text-brand-300 transition-colors">{job.title}</h3>
                          <p className="text-xs text-surface-400 mt-0.5">{job.company} · {job.location}</p>
                        </div>
                        <button onClick={(e) => handleSave(e, job._id)}
                          className={`shrink-0 p-1.5 rounded-lg transition-colors ${saved.has(job._id) ? 'text-brand-400' : 'text-surface-600 hover:text-surface-300'}`}>
                          <svg className="w-4 h-4" fill={saved.has(job._id) ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-2.5">
                        <Badge variant={typeColors[job.type] || 'default'}>{job.type}</Badge>
                        {job.skills?.slice(0, 3).map(s => <Badge key={s}>{s}</Badge>)}
                        {job.salaryRange && <span className="text-xs text-success-400 font-medium">{job.salaryRange}</span>}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )
      }

      {(data?.pages || 1) > 1 && (
        <div className="flex justify-center gap-2">
          <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>← Prev</Button>
          <span className="text-sm text-surface-400 px-2">Page {page} of {data.pages}</span>
          <Button variant="secondary" size="sm" disabled={page >= data.pages} onClick={() => setPage(p => p + 1)}>Next →</Button>
        </div>
      )}

      {/* Job Detail Modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title={selected?.title} size="lg">
        {selected && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-surface-700 flex items-center justify-center text-lg font-bold text-surface-300">
                {selected.company?.[0]}
              </div>
              <div>
                <p className="font-semibold text-white">{selected.company}</p>
                <p className="text-sm text-surface-400">{selected.location}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge variant={typeColors[selected.type] || 'default'}>{selected.type}</Badge>
              {selected.salaryRange && <span className="text-sm text-success-400 font-medium">{selected.salaryRange}</span>}
            </div>
            {selected.description && (
              <p className="text-sm text-surface-300 leading-relaxed">{selected.description}</p>
            )}
            {selected.skills?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-surface-400 uppercase tracking-wider mb-2">Required Skills</p>
                <div className="flex flex-wrap gap-1.5">
                  {selected.skills.map(s => <Badge key={s}>{s}</Badge>)}
                </div>
              </div>
            )}
            <div className="flex gap-3 pt-2">
              {selected.applyUrl
                ? <a href={selected.applyUrl} target="_blank" rel="noopener noreferrer">
                    <Button>Apply Now →</Button>
                  </a>
                : <Button>Apply Now</Button>
              }
              <Button variant="secondary" onClick={() => setSelected(null)}>Close</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}