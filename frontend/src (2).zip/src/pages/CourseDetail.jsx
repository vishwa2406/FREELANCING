import { useParams, Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { courseAPI, progressAPI, quizAPI } from '../services/api'
import { useApi } from '../hooks/useApi'
import Badge from '../components/ui/Badge'
import Button from '../components/ui/Button'
import Spinner from '../components/ui/Spinner'
import ProgressBar from '../components/ui/ProgressBar'

export default function CourseDetail() {
  const { id } = useParams()
  const navigate = useNavigate()

  const { data, loading } = useApi(() => courseAPI.get(id), [id], { defaultData: null })
  const { data: progressData } = useApi(() => progressAPI.me(id), [id], { defaultData: null })
  const { data: quizData } = useApi(() => quizAPI.byCourse(id), [id], { defaultData: { quizzes: [] } })

  const course   = data?.course
  const lessons  = data?.lessons || []
  const quizzes  = quizData?.quizzes || []
  const progress = progressData?.progress

  const completedLessons = progress?.completedLessons?.length || 0
  const progressPct = lessons.length > 0 ? Math.round((completedLessons / lessons.length) * 100) : 0

  if (loading) return (
    <div className="flex items-center justify-center py-24"><Spinner size="lg" /></div>
  )
  if (!course) return (
    <div className="text-center py-24">
      <p className="text-surface-400">Course not found.</p>
      <Link to="/courses" className="text-brand-400 mt-2 inline-block">Back to courses</Link>
    </div>
  )

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Back */}
      <Link to="/courses" className="inline-flex items-center gap-2 text-sm text-surface-400 hover:text-white transition-colors">
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        Back to Courses
      </Link>

      {/* Hero */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        className="glass-dark rounded-2xl overflow-hidden">
        <div className="h-56 md:h-72 bg-gradient-to-br from-surface-800 to-brand-950 relative">
          {course.thumbnail
            ? <img src={course.thumbnail} className="w-full h-full object-cover opacity-60" alt={course.title} />
            : <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(52,120,246,0.2),transparent_70%)]" />
          }
          <div className="absolute inset-0 flex flex-col justify-end p-6">
            <div className="flex gap-2 mb-3">
              <Badge variant={course.level}>{course.level}</Badge>
              <Badge variant="default">{course.category}</Badge>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white leading-tight">{course.title}</h1>
            <p className="text-surface-300 text-sm mt-1">by {course.instructor}</p>
          </div>
        </div>
        <div className="p-6">
          <p className="text-surface-300 text-sm leading-relaxed mb-4">{course.description}</p>
          <div className="flex flex-wrap gap-4 text-sm text-surface-400 mb-5">
            <span>⏱ {course.estimatedHours} hours</span>
            <span>📚 {lessons.length} lessons</span>
            <span>❓ {quizzes.length} quizzes</span>
            {course.rating > 0 && <span className="text-warning-400">★ {course.rating} rating</span>}
            <span>👥 {course.enrolledCount || 0} enrolled</span>
          </div>

          {/* Progress */}
          {completedLessons > 0 && (
            <div className="mb-5">
              <ProgressBar value={progressPct} showLabel label={`${completedLessons}/${lessons.length} lessons completed`} color="success" size="md" />
            </div>
          )}

          <div className="flex gap-3 flex-wrap">
            <Button onClick={() => navigate(`/courses/${id}/watch`)} size="lg"
              icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
            >
              {completedLessons > 0 ? 'Continue Learning' : 'Start Course'}
            </Button>
            <Button variant="secondary" onClick={() => courseAPI.bookmark(id)}>
              ♡ Bookmark
            </Button>
          </div>
        </div>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Lessons */}
        <div className="md:col-span-2 space-y-3">
          <h2 className="font-semibold text-white">Course Curriculum ({lessons.length} lessons)</h2>
          {lessons.length === 0
            ? <div className="glass-dark rounded-2xl p-8 text-center text-surface-500 text-sm">No lessons added yet.</div>
            : (
              <div className="glass-dark rounded-2xl overflow-hidden">
                {lessons.map((lesson, i) => {
                  const done = progress?.completedLessons?.includes(lesson._id)
                  return (
                    <motion.div key={lesson._id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * .04 }}
                      className="flex items-center gap-4 px-5 py-3.5 border-b border-surface-800 last:border-0 hover:bg-surface-800/50 transition-colors group">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 ${done ? 'bg-success-500/20 text-success-400 border border-success-500/30' : 'bg-surface-800 text-surface-400 border border-surface-700'}`}>
                        {done ? '✓' : i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-surface-200 group-hover:text-white transition-colors">{lesson.title}</p>
                        {lesson.duration && <p className="text-xs text-surface-500 mt-0.5">{lesson.duration} min</p>}
                      </div>
                      {lesson.videoUrl && (
                        <svg className="w-4 h-4 text-surface-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                      )}
                    </motion.div>
                  )
                })}
              </div>
            )
          }
        </div>

        {/* Side info */}
        <div className="space-y-4">
          {/* Tags */}
          {course.tags?.length > 0 && (
            <div className="glass-dark rounded-2xl p-4">
              <h3 className="text-sm font-semibold text-white mb-3">Tags</h3>
              <div className="flex flex-wrap gap-1.5">
                {course.tags.map(tag => <Badge key={tag} variant="default">{tag}</Badge>)}
              </div>
            </div>
          )}

          {/* Outcomes */}
          {course.outcomes?.length > 0 && (
            <div className="glass-dark rounded-2xl p-4">
              <h3 className="text-sm font-semibold text-white mb-3">What you'll learn</h3>
              <ul className="space-y-2">
                {course.outcomes.map((o, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-surface-300">
                    <span className="text-success-400 shrink-0 mt-0.5">✓</span>{o}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Quizzes */}
          {quizzes.length > 0 && (
            <div className="glass-dark rounded-2xl p-4">
              <h3 className="text-sm font-semibold text-white mb-3">Quizzes</h3>
              {quizzes.map(q => (
                <Link key={q._id} to={`/quiz/${q._id}`}
                  className="flex items-center justify-between py-2 border-b border-surface-800 last:border-0 hover:opacity-80 transition-opacity">
                  <span className="text-xs text-surface-300">{q.title}</span>
                  <svg className="w-4 h-4 text-brand-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}