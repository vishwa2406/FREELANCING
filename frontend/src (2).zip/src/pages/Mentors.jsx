import { useState } from 'react'
import { motion } from 'framer-motion'
import { mentorAPI } from '../services/api'
import { useApi } from '../hooks/useApi'
import { useToast } from '../context/ToastContext'
import Button from '../components/ui/Button'
import Badge from '../components/ui/Badge'
import Modal from '../components/ui/Modal'
import Textarea from '../components/ui/Textarea'
import Spinner from '../components/ui/Spinner'
import EmptyState from '../components/ui/EmptyState'

export default function Mentors() {
  const { toast } = useToast()
  const { data, loading } = useApi(mentorAPI.list, [], { defaultData: { mentors: [] } })
  const { data: myReqs }  = useApi(mentorAPI.mine, [], { defaultData: { requests: [] } })

  const mentors  = data?.mentors || []
  const requests = myReqs?.requests || []

  const [selected, setSelected] = useState(null)
  const [message, setMessage]   = useState('')
  const [sending, setSending]   = useState(false)
  const [msgError, setMsgError] = useState('')

  const pendingIds = new Set(requests.filter(r => r.status === 'pending').map(r => r.mentor?._id))

  const handleRequest = async () => {
    if (!message.trim()) { setMsgError('Please add a message'); return }
    setSending(true)
    try {
      await mentorAPI.request({ mentorId: selected._id, message })
      toast('Mentorship request sent!', 'success')
      setSelected(null)
      setMessage('')
      setMsgError('')
    } catch (err) {
      toast(err.response?.data?.message || 'Request failed', 'error')
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-white">Mentors</h1>
        <p className="text-surface-400 text-sm mt-0.5">Connect with experienced professionals</p>
      </div>

      {/* My requests */}
      {requests.length > 0 && (
        <div className="glass-dark rounded-2xl p-5">
          <h2 className="font-semibold text-white mb-3 text-sm">My Requests</h2>
          <div className="space-y-2">
            {requests.map(req => (
              <div key={req._id} className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-surface-700 flex items-center justify-center text-sm font-semibold text-white">
                    {req.mentor?.name?.[0] || '?'}
                  </div>
                  <p className="text-sm text-surface-200">{req.mentor?.name}</p>
                </div>
                <Badge variant={req.status === 'pending' ? 'warning' : req.status === 'accepted' ? 'success' : 'danger'}>
                  {req.status}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Mentor grid */}
      {loading
        ? <div className="flex justify-center py-10"><Spinner size="lg" /></div>
        : mentors.length === 0
          ? <EmptyState title="No mentors available" description="Check back soon for available mentors."
              icon={<svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>}
            />
          : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {mentors.map((mentor, i) => (
                <motion.div key={mentor._id} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * .07 }}
                  whileHover={{ y: -3 }}
                  className="glass-dark rounded-2xl p-5 flex flex-col">
                  {/* Avatar */}
                  <div className="flex items-center gap-3 mb-4">
                    {mentor.avatar
                      ? <img src={mentor.avatar} className="w-12 h-12 rounded-full object-cover" alt={mentor.name} />
                      : <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-xl font-bold text-white">
                          {mentor.name?.[0] || 'M'}
                        </div>
                    }
                    <div>
                      <h3 className="font-semibold text-white">{mentor.name}</h3>
                      <p className="text-xs text-surface-400">{mentor.email}</p>
                    </div>
                  </div>

                  {mentor.bio && (
                    <p className="text-xs text-surface-400 leading-relaxed mb-4 line-clamp-3">{mentor.bio}</p>
                  )}

                  {mentor.skills?.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-4 flex-1">
                      {mentor.skills.slice(0, 4).map(s => (
                        <Badge key={s} variant="default">{s}</Badge>
                      ))}
                    </div>
                  )}

                  <Button full
                    variant={pendingIds.has(mentor._id) ? 'secondary' : 'primary'}
                    disabled={pendingIds.has(mentor._id)}
                    onClick={() => { setSelected(mentor); setMessage(''); setMsgError('') }}
                  >
                    {pendingIds.has(mentor._id) ? '⏳ Requested' : 'Request Mentorship'}
                  </Button>
                </motion.div>
              ))}
            </div>
          )
      }

      {/* Request Modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title={`Request Mentorship from ${selected?.name}`}>
        {selected && (
          <div className="space-y-4">
            <p className="text-sm text-surface-400">
              Send a message explaining what you'd like to learn from <span className="text-white font-medium">{selected.name}</span>.
            </p>
            <Textarea
              label="Your message"
              placeholder="Hi! I'd love to learn about..."
              rows={5}
              value={message}
              onChange={e => { setMessage(e.target.value); setMsgError('') }}
              error={msgError}
              hint="Be specific about your goals and what you're hoping to achieve."
            />
            <div className="flex gap-3">
              <Button full loading={sending} onClick={handleRequest}>Send Request</Button>
              <Button variant="secondary" onClick={() => setSelected(null)}>Cancel</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}