import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { progressAPI, courseAPI } from '../services/api'
import { useApi } from '../hooks/useApi'
import ProgressBar from '../components/ui/ProgressBar'
import Spinner from '../components/ui/Spinner'
import Badge from '../components/ui/Badge'
import EmptyState from '../components/ui/EmptyState'
import Button from '../components/ui/Button'

export default function Progress() {
  const { data: progressData, loading: pLoading } = useApi(progressAPI.me, [], { defaultData: { progresses: [] } })
  const { data: coursesData, loading: cLoading }  = useApi(courseAPI.list, [], { defaultData: { courses: [] } })

  const progresses = progressData?.progresses || []
  const courses    = coursesData?.courses || []

  const courseMap = {}
  courses.forEach(c => { courseMap[c._id] = c })

  const loading = pLoading || cLoading

  const totalLessons = progresses.reduce((acc, p) => acc + (p.totalLessons || 0), 0)
  const completedTotal = progresses.reduce((acc, p) => acc + (p.completedLessons?.length || 0), 0)
  const overallPct = totalLessons > 0 ? Math.round((completedTotal / totalLessons) * 100) : 0
  const completedCourses = progresses.filter(p => p.completed).length

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-white">Learning Progress</h1>
        <p className="text-surface-400 text-sm mt-0.5">Track your learning journey</p>
      </div>

      {/* Overview cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Enrolled', value: progresses.length, color: 'from-brand-500/20 to-brand-600/5 text-brand-400' },
          { label: 'Completed', value: completedCourses, color: 'from-success-500/20 to-success-600/5 text-success-400' },
          { label: 'Lessons Done', value: completedTotal, color: 'from-warning-500/20 to-warning-600/5 text-warning-400' },
          { label: 'Overall %', value: `${overallPct}%`, color: 'from-danger-500/20 to-danger-600/5 text-danger-400' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * .08 }}
            className="glass-dark rounded-2xl p-5">
            <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center mb-3`}>
              <span className="text-sm font-bold">{typeof s.value === 'number' ? s.value : '+'}</span>
            </div>
            <p className="text-xs text-surface-500 mb-0.5">{s.label}</p>
            <p className="text-2xl font-bold text-white">{s.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Overall bar */}
      {progresses.length > 0 && (
        <div className="glass-dark rounded-2xl p-5">
          <div className="flex justify-between items-center mb-3">
            <p className="font-medium text-white">Overall Progress</p>
            <span className="text-sm text-brand-400 font-semibold">{overallPct}%</span>
          </div>
          <ProgressBar value={overallPct} size="lg" color="brand" />
          <p className="text-xs text-surface-500 mt-2">{completedTotal} of {totalLessons} lessons completed</p>
        </div>
      )}

      {/* Course list */}
      {loading
        ? <div className="flex justify-center py-10"><Spinner size="lg" /></div>
        : progresses.length === 0
          ? <EmptyState title="No courses started yet"
              description="Enroll in a course to track your progress here."
              icon={<svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10" /></svg>}
              action={<Link to="/courses"><Button>Browse Courses</Button></Link>}
            />
          : (
            <div className="space-y-3">
              <h2 className="font-semibold text-white">Your Courses</h2>
              {progresses.map((prog, i) => {
                const course = courseMap[prog.course]
                const pct = prog.totalLessons > 0
                  ? Math.round((prog.completedLessons?.length / prog.totalLessons) * 100) : 0
                return (
                  <motion.div key={prog._id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * .06 }}
                    className="glass-dark rounded-2xl p-5">
                    <div className="flex items-start gap-4">
                      <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-brand-500/20 to-brand-700/10 flex items-center justify-center shrink-0">
                        <svg className="w-5 h-5 text-brand-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13" /></svg>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <h3 className="font-semibold text-white text-sm">{course?.title || 'Unknown Course'}</h3>
                          {prog.completed && <Badge variant="success">✓ Completed</Badge>}
                        </div>
                        <p className="text-xs text-surface-500 mb-3">
                          {prog.completedLessons?.length || 0} / {prog.totalLessons || 0} lessons
                          {prog.lastActivity && ` · Last active ${new Date(prog.lastActivity).toLocaleDateString()}`}
                        </p>
                        <ProgressBar value={pct} size="md" color={prog.completed ? 'success' : 'brand'} showLabel />
                      </div>
                      <Link to={`/courses/${prog.course}/watch`}>
                        <Button variant="secondary" size="sm">
                          {prog.completed ? 'Review' : 'Continue'}
                        </Button>
                      </Link>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          )
      }
    </div>
  )
}