import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000,
})

api.interceptors.request.use(config => {
  const token = localStorage.getItem('cegp_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('cegp_token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default api

export const authAPI = {
  register: d  => api.post('/auth/register', d),
  login:    d  => api.post('/auth/login', d),
  forgot:   d  => api.post('/auth/forgot-password', d),
  reset:    d  => api.post('/auth/reset-password', d),
  me:       () => api.get('/users/me'),
  update:   d  => api.patch('/users/me', d),
}

export const courseAPI = {
  list:        p  => api.get('/courses', { params: p }),
  get:         id => api.get(`/courses/${id}`),
  recommended: () => api.get('/courses/recommended'),
  bookmark:    id => api.post(`/courses/${id}/bookmark`),
  lessons:     id => api.get(`/courses/${id}/lessons`),
}

export const quizAPI = {
  get:      id     => api.get(`/quizzes/${id}`),
  submit:   (id,d) => api.post(`/quizzes/${id}/attempt`, d),
  attempts: id     => api.get(`/quizzes/${id}/attempts/me`),
  byCourse: cid    => api.get(`/courses/${cid}/quizzes`),
}

export const jobAPI = {
  list:        p  => api.get('/jobs', { params: p }),
  get:         id => api.get(`/jobs/${id}`),
  save:        id => api.post(`/jobs/${id}/save`),
  recommended: () => api.get('/jobs/recommended'),
}

export const progressAPI = {
  me:       cid => api.get('/progress/me', { params: { courseId: cid } }),
  complete: d   => api.post('/progress/complete', d),
}

export const mentorAPI = {
  list:    () => api.get('/mentors'),
  request: d  => api.post('/mentors/request', d),
  mine:    () => api.get('/mentors/my-requests'),
}

export const notifAPI = {
  list: ()  => api.get('/notifications'),
  read: id  => api.patch(`/notifications/${id}/read`),
}