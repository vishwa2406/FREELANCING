import { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { notifAPI } from '../../services/api'
import { useApi } from '../../hooks/useApi'
import { AnimatePresence, motion } from 'framer-motion'

export default function Topbar({ onMenuClick }) {
  const { user } = useAuth()
  const [notifOpen, setNotifOpen] = useState(false)
  const { data } = useApi(notifAPI.list, [], { defaultData: { notifications: [] } })
  const notifs = data?.notifications || []
  const unread = notifs.filter(n => !n.read).length

  return (
    <header className="h-16 border-b border-surface-700/50 bg-surface-900/80 backdrop-blur-xl flex items-center gap-4 px-4 md:px-6 shrink-0 sticky top-0 z-20">
      <button onClick={onMenuClick} className="lg:hidden text-surface-400 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-surface-800">
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
      </button>

      <div className="flex-1 max-w-md">
        <div className="relative">
          <svg className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-surface-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input placeholder="Search courses, jobs…" className="w-full pl-9 pr-4 py-2 bg-surface-800 border border-surface-700 hover:border-surface-600 focus:border-brand-500 rounded-xl text-sm text-surface-100 placeholder-surface-500 focus-ring transition-all" />
        </div>
      </div>

      <div className="flex items-center gap-2 ml-auto">
        {/* Notifications */}
        <div className="relative">
          <button onClick={() => setNotifOpen(v => !v)}
            className="relative p-2 text-surface-400 hover:text-white hover:bg-surface-800 rounded-xl transition-all">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
            {unread > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-500 rounded-full" />
            )}
          </button>
          <AnimatePresence>
            {notifOpen && (
              <motion.div initial={{ opacity: 0, y: 8, scale: .96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: .96 }}
                transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                className="absolute right-0 top-12 w-80 glass-dark rounded-2xl shadow-card-lg overflow-hidden z-50">
                <div className="p-4 border-b border-surface-700/50">
                  <p className="font-semibold text-sm text-white">Notifications</p>
                </div>
                <div className="max-h-72 overflow-y-auto">
                  {notifs.length === 0
                    ? <p className="text-sm text-surface-500 text-center py-8">No notifications</p>
                    : notifs.slice(0, 8).map(n => (
                      <div key={n._id} className={`px-4 py-3 border-b border-surface-800 hover:bg-surface-800/50 transition-colors ${!n.read ? 'bg-brand-500/5' : ''}`}>
                        <p className="text-sm text-surface-200">{n.message}</p>
                        <p className="text-xs text-surface-500 mt-0.5">{new Date(n.createdAt).toLocaleDateString()}</p>
                      </div>
                    ))
                  }
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-semibold text-xs select-none">
          {user?.name?.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase() || 'U'}
        </div>
      </div>
    </header>
  )
}