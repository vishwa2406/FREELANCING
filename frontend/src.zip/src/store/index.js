import { configureStore } from '@reduxjs/toolkit';
import authReducer from './authSlice';
import courseReducer from './courseSlice';
import jobReducer from './jobSlice';
import uiReducer from './uiSlice';

const store = configureStore({
  reducer: { auth: authReducer, courses: courseReducer, jobs: jobReducer, ui: uiReducer },
});

export default store;