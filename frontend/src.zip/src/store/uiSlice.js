import { createSlice } from '@reduxjs/toolkit';

const uiSlice = createSlice({
  name: 'ui',
  initialState: { darkMode: localStorage.getItem('cegp_theme') === 'dark', sidebarOpen: true },
  reducers: {
    toggleDarkMode: (state) => {
      state.darkMode = !state.darkMode;
      localStorage.setItem('cegp_theme', state.darkMode ? 'dark' : 'light');
      document.documentElement.classList.toggle('dark', state.darkMode);
    },
    setSidebar: (state, action) => { state.sidebarOpen = action.payload; },
  },
});

export const { toggleDarkMode, setSidebar } = uiSlice.actions;
export default uiSlice.reducer;