import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../utils/api';

export const fetchJobs = createAsyncThunk('jobs/fetchAll', async (params = {}) => {
  const { data } = await api.get('/jobs', { params });
  return data;
});

export const fetchRecommendedJobs = createAsyncThunk('jobs/recommended', async () => {
  const { data } = await api.get('/jobs/recommended');
  return data;
});

const jobSlice = createSlice({
  name: 'jobs',
  initialState: { list: [], recommended: [], total: 0, loading: false },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchJobs.pending, (s) => { s.loading = true; })
      .addCase(fetchJobs.fulfilled, (s, a) => { s.loading = false; s.list = a.payload.jobs; s.total = a.payload.total; })
      .addCase(fetchRecommendedJobs.fulfilled, (s, a) => { s.recommended = a.payload.jobs; });
  },
});

export default jobSlice.reducer;