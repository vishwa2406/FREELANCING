import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../utils/api';

export const loginUser = createAsyncThunk('auth/login', async (creds, { rejectWithValue }) => {
  try {
    const { data } = await api.post('/auth/login', creds);
    localStorage.setItem('cegp_token', data.token);
    return data;
  } catch (err) { return rejectWithValue(err.response?.data?.message || 'Login failed'); }
});

export const registerUser = createAsyncThunk('auth/register', async (creds, { rejectWithValue }) => {
  try {
    const { data } = await api.post('/auth/register', creds);
    localStorage.setItem('cegp_token', data.token);
    return data;
  } catch (err) { return rejectWithValue(err.response?.data?.message || 'Registration failed'); }
});

export const fetchMe = createAsyncThunk('auth/me', async (_, { rejectWithValue }) => {
  try {
    const { data } = await api.get('/auth/me');
    return data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const updateProfile = createAsyncThunk('auth/updateProfile', async (profileData, { rejectWithValue }) => {
  try {
    const { data } = await api.patch('/auth/me', profileData);
    return data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

const authSlice = createSlice({
  name: 'auth',
  initialState: { user: null, token: localStorage.getItem('cegp_token'), loading: false, error: null, initialized: false },
  reducers: {
    logout: (state) => {
      state.user = null; state.token = null;
      localStorage.removeItem('cegp_token');
    },
    clearError: (state) => { state.error = null; },
  },
  extraReducers: (builder) => {
    const handle = (thunk) => builder
      .addCase(thunk.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(thunk.fulfilled, (s, a) => { s.loading = false; s.user = a.payload.user; s.token = a.payload.token || s.token; if (thunk === fetchMe) s.initialized = true; })
      .addCase(thunk.rejected, (s, a) => { s.loading = false; s.error = a.payload; if (thunk === fetchMe) s.initialized = true; });
    handle(loginUser); handle(registerUser); handle(fetchMe); handle(updateProfile);
  },
});

export const { logout, clearError } = authSlice.actions;
export default authSlice.reducer;