import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../utils/api';

export const fetchCourses = createAsyncThunk('courses/fetchAll', async (params = {}) => {
  const { data } = await api.get('/courses', { params });
  return data;
});

export const fetchCourse = createAsyncThunk('courses/fetchOne', async (id) => {
  const { data } = await api.get(`/courses/${id}`);
  return data;
});

export const fetchRecommended = createAsyncThunk('courses/recommended', async () => {
  const { data } = await api.get('/courses/recommended');
  return data;
});

const courseSlice = createSlice({
  name: 'courses',
  initialState: { list: [], current: null, recommended: [], total: 0, pages: 1, loading: false, error: null },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCourses.pending, (s) => { s.loading = true; })
      .addCase(fetchCourses.fulfilled, (s, a) => { s.loading = false; s.list = a.payload.courses; s.total = a.payload.total; s.pages = a.payload.pages; })
      .addCase(fetchCourses.rejected, (s, a) => { s.loading = false; s.error = a.error.message; })
      .addCase(fetchCourse.fulfilled, (s, a) => { s.current = a.payload; })
      .addCase(fetchRecommended.fulfilled, (s, a) => { s.recommended = a.payload.courses; });
  },
});

export default courseSlice.reducer;