import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MdArrowBack, MdArrowForward, MdCheckCircle } from 'react-icons/md';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function LessonView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [lesson, setLesson] = useState(null);
  const [quizzes, setQuizzes] = useState([]);
  const [marked, setMarked] = useState(false);

  useEffect(() => {
    api.get(`/lessons/${id}`).then(r => {
      setLesson(r.data.lesson);
      api.get(`/quizzes/course/${r.data.lesson.course._id}`).then(q => setQuizzes(q.data.quizzes));
    });
  }, [id]);

  const handleMarkComplete = async () => {
    try {
      await api.post('/progress/mark', { courseId: lesson.course._id, lessonId: lesson._id });
      setMarked(true);
      toast.success('Lesson marked as complete!');
    } catch (err) {
      toast.error('Could not update progress');
    }
  };

  if (!lesson) return (
    <div className="p-6 max-w-4xl mx-auto space-y-4">
      <div className="skeleton h-8 w-48" />
      <div className="skeleton h-96 w-full" />
    </div>
  );

  const embedUrl = lesson.videoUrl?.replace('watch?v=', 'embed/');

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(`/courses/${lesson.course._id}`)} className="btn-ghost flex items-center gap-2 text-sm">
          <MdArrowBack size={18} />
          <span className="truncate max-w-xs">{lesson.course.title}</span>
        </button>
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="font-display font-bold text-2xl text-slate-900 dark:text-white mb-1">{lesson.title}</h1>
        <p className="text-slate-500 text-sm">{lesson.description}</p>
      </motion.div>

      {/* Video */}
      {embedUrl && (
        <div className="card overflow-hidden">
          <div className="aspect-video bg-slate-900">
            <iframe src={embedUrl} title={lesson.title} className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen />
          </div>
        </div>
      )}

      {/* Notes */}
      {lesson.content && (
        <div className="card p-6">
          <h2 className="font-display font-semibold text-slate-900 dark:text-white mb-3">Lesson Notes</h2>
          <div className="prose prose-slate dark:prose-invert prose-sm max-w-none text-slate-600 dark:text-slate-400 leading-relaxed">
            {lesson.content}
          </div>
        </div>
      )}

      {/* Quizzes for this lesson */}
      {quizzes.length > 0 && (
        <div className="card p-6">
          <h2 className="font-display font-semibold text-slate-900 dark:text-white mb-3">Test Your Knowledge</h2>
          <div className="space-y-2">
            {quizzes.map(q => (
              <button key={q._id} onClick={() => navigate(`/quiz/${q._id}`)}
                className="w-full text-left p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-brand-400 hover:bg-brand-50 dark:hover:bg-brand-900/10 transition-all">
                <p className="font-medium text-slate-900 dark:text-white text-sm">{q.title}</p>
                <p className="text-xs text-slate-500 mt-0.5">Passing score: {q.passingScore}%</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Mark complete */}
      <div className="flex justify-end">
        <button onClick={handleMarkComplete} disabled={marked}
          className={`flex items-center gap-2 ${marked ? 'btn-secondary text-emerald-600 cursor-not-allowed' : 'btn-primary'}`}>
          <MdCheckCircle size={18} />
          {marked ? 'Completed!' : 'Mark as Complete'}
        </button>
      </div>
    </div>
  );
}