import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import { MdSearch, MdFilterList } from 'react-icons/md';
import { fetchCourses } from '../store/courseSlice';
import CourseCard from '../components/courses/CourseCard';
import SkeletonCard from '../components/common/SkeletonCard';
import useDebounce from '../hooks/useDebounce';

const levels = ['', 'beginner', 'intermediate', 'advanced'];
const categories = ['', 'Web Development', 'Frontend', 'Backend', 'Data Science', 'Design', 'Marketing'];

export default function Courses() {
  const dispatch = useDispatch();
  const { list, loading, total, pages } = useSelector(s => s.courses);
  const [filters, setFilters] = useState({ search: '', level: '', category: '', page: 1 });
  const debouncedSearch = useDebounce(filters.search);

  useEffect(() => {
    dispatch(fetchCourses({ ...filters, search: debouncedSearch, limit: 12 }));
  }, [debouncedSearch, filters.level, filters.category, filters.page]);

  const update = (key, val) => setFilters(p => ({ ...p, [key]: val, page: 1 }));

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display font-bold text-3xl text-slate-900 dark:text-white">Explore Courses</h1>
        <p className="text-slate-500 mt-1">{total} courses available</p>
      </motion.div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-64 px-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus-within:border-brand-500 transition-all">
          <MdSearch size={18} className="text-slate-400" />
          <input value={filters.search} onChange={e => update('search', e.target.value)}
            placeholder="Search courses..." className="bg-transparent text-sm outline-none flex-1 text-slate-700 dark:text-slate-300 placeholder:text-slate-400" />
        </div>
        <select value={filters.level} onChange={e => update('level', e.target.value)}
          className="input w-auto min-w-36 text-sm">
          {levels.map(l => <option key={l} value={l}>{l ? l.charAt(0).toUpperCase() + l.slice(1) : 'All Levels'}</option>)}
        </select>
        <select value={filters.category} onChange={e => update('category', e.target.value)}
          className="input w-auto min-w-44 text-sm">
          {categories.map(c => <option key={c} value={c}>{c || 'All Categories'}</option>)}
        </select>
      </div>

      {/* Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {loading
          ? Array(8).fill(0).map((_, i) => <SkeletonCard key={i} />)
          : list.map((c, i) => <CourseCard key={c._id} course={c} index={i} />)
        }
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex justify-center gap-2">
          {Array.from({ length: pages }, (_, i) => i + 1).map(p => (
            <button key={p} onClick={() => setFilters(f => ({ ...f, page: p }))}
              className={`w-9 h-9 rounded-xl text-sm font-medium transition-all ${filters.page === p ? 'bg-brand-500 text-white' : 'btn-secondary'}`}>
              {p}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}