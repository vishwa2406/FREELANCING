import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MdArrowForward, MdSchool, MdWork, MdPeople, MdTrendingUp } from 'react-icons/md';

const features = [
  { icon: MdSchool, title: 'Expert-Led Courses', desc: 'Learn from industry professionals with hands-on projects and real certifications.', color: 'text-brand-500 bg-brand-50 dark:bg-brand-900/20' },
  { icon: MdWork, title: 'Smart Job Board', desc: 'AI-powered job recommendations matched to your skills and learning progress.', color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-900/20' },
  { icon: MdPeople, title: '1-on-1 Mentorship', desc: 'Connect with senior mentors for personalized guidance and career direction.', color: 'text-amber-500 bg-amber-50 dark:bg-amber-900/20' },
  { icon: MdTrendingUp, title: 'Track Progress', desc: 'Detailed analytics on your learning journey, quiz scores, and career goals.', color: 'text-rose-500 bg-rose-50 dark:bg-rose-900/20' },
];

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 font-body">
      {/* Navbar */}
      <nav className="fixed top-0 inset-x-0 z-50 border-b border-slate-100 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center">
              <span className="text-white font-display font-bold text-xs">CG</span>
            </div>
            <span className="font-display font-bold text-slate-900 dark:text-white">CEGP</span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/login')} className="btn-ghost text-sm">Sign In</button>
            <button onClick={() => navigate('/register')} className="btn-primary text-sm">Get Started</button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-24 px-6 relative overflow-hidden">
        {/* Background blobs */}
        <div className="absolute top-20 left-1/4 w-72 h-72 bg-brand-400/20 rounded-full blur-3xl" />
        <div className="absolute top-40 right-1/4 w-96 h-96 bg-purple-400/15 rounded-full blur-3xl" />

        <div className="max-w-4xl mx-auto text-center relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="inline-flex items-center gap-2 badge bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 border border-brand-200 dark:border-brand-800 mb-6 px-4 py-1.5 text-sm">
              🎯 Career & Skill Development Platform
            </span>
            <h1 className="font-display font-extrabold text-5xl md:text-7xl text-slate-900 dark:text-white leading-tight mb-6">
              Grow Your Career with
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-500 to-purple-600"> Smart Learning</span>
            </h1>
            <p className="text-xl text-slate-600 dark:text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
              Courses, mentorship, and job opportunities — all personalized to your skills and goals. Join thousands of learners building their future.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button onClick={() => navigate('/register')}
                className="btn-primary text-base flex items-center justify-center gap-2 px-8 py-3.5">
                Start Learning Free <MdArrowForward size={20} />
              </button>
              <button onClick={() => navigate('/courses')}
                className="btn-secondary text-base px-8 py-3.5">
                Browse Courses
              </button>
            </div>
          </motion.div>

          {/* Stats row */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
            className="flex flex-wrap justify-center gap-8 mt-16">
            {[['1,200+', 'Enrolled Learners'], ['50+', 'Expert Courses'], ['30+', 'Mentors'], ['95%', 'Satisfaction Rate']].map(([val, label]) => (
              <div key={label} className="text-center">
                <p className="font-display font-bold text-3xl text-slate-900 dark:text-white">{val}</p>
                <p className="text-sm text-slate-500 mt-1">{label}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-6 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="font-display font-bold text-4xl text-slate-900 dark:text-white mb-4">Everything you need to succeed</h2>
            <p className="text-slate-600 dark:text-slate-400 text-lg">A complete platform designed for serious career growth</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map(({ icon: Icon, title, desc, color }, i) => (
              <motion.div key={title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }} viewport={{ once: true }}
                className="card p-6 text-center">
                <div className={`w-14 h-14 rounded-2xl ${color} flex items-center justify-center mx-auto mb-4`}>
                  <Icon size={28} />
                </div>
                <h3 className="font-display font-semibold text-slate-900 dark:text-white mb-2">{title}</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">{desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="font-display font-bold text-4xl text-slate-900 dark:text-white mb-4">Ready to start your journey?</h2>
          <p className="text-slate-600 dark:text-slate-400 mb-8">Join the community of learners and build a career you love.</p>
          <button onClick={() => navigate('/register')} className="btn-primary text-base px-10 py-4">
            Create Free Account
          </button>
        </div>
      </section>

      <footer className="border-t border-slate-100 dark:border-slate-800 py-8 text-center text-sm text-slate-500">
        © 2026 CEGP — Community Empowerment & Growth Portal
      </footer>
    </div>
  );
}