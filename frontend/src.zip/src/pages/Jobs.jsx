import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import { MdSearch } from 'react-icons/md';
import { fetchJobs } from '../store/jobSlice';
import JobCard from '../components/jobs/JobCard';
import SkeletonCard from '../components/common/SkeletonCard';
import useDebounce from '../hooks/useDebounce';

const types = ['', 'full-time', 'part-time', 'internship', 'remote', 'freelance'];

export default function Jobs() {
  const dispatch = useDispatch();
  const { list, loading, total } = useSelector(s => s.jobs);
  const [filters, setFilters] = useState({ search: '', type: '', location: '', skill: '' });
  const debSearch = useDebounce(filters.search);

  useEffect(() => {
    dispatch(fetchJobs({ ...filters, search: debSearch }));
  }, [debSearch, filters.type, filters.location, filters.skill]);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display font-bold text-3xl text-slate-900 dark:text-white">Job Board</h1>
        <p className="text-slate-500 mt-1">{total} opportunities available</p>
      </motion.div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-56 px-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus-within:border-brand-500 transition-all">
          <MdSearch size={18} className="text-slate-400" />
          <input value={filters.search} onChange={e => setFilters(p => ({ ...p, search: e.target.value }))}
            placeholder="Search jobs, companies..." className="bg-transparent text-sm outline-none flex-1 text-slate-700 dark:text-slate-300 placeholder:text-slate-400" />
        </div>
        <select value={filters.type} onChange={e => setFilters(p => ({ ...p, type: e.target.value }))}
          className="input w-auto min-w-36 text-sm">
          {types.map(t => <option key={t} value={t}>{t ? t.charAt(0).toUpperCase() + t.slice(1) : 'All Types'}</option>)}
        </select>
        <input value={filters.location} onChange={e => setFilters(p => ({ ...p, location: e.target.value }))}
          placeholder="Location..." className="input w-auto min-w-36 text-sm" />
        <input value={filters.skill} onChange={e => setFilters(p => ({ ...p, skill: e.target.value }))}
          placeholder="Skill..." className="input w-auto min-w-32 text-sm" />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {loading
          ? Array(6).fill(0).map((_, i) => <SkeletonCard key={i} />)
          : list.map((job, i) => <JobCard key={job._id} job={job} index={i} />)
        }
      </div>
    </div>
  );
}