import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import { MdEdit, MdSave } from 'react-icons/md';
import { updateProfile } from '../store/authSlice';
import ProgressBar from '../components/common/ProgressBar';
import toast from 'react-hot-toast';
import { getInitials } from '../utils/helpers';

const ALL_SKILLS = ['JavaScript', 'Python', 'React', 'Node.js', 'CSS', 'HTML', 'Data Science', 'UI/UX', 'Digital Marketing', 'Java', 'SQL', 'MongoDB', 'Express', 'Figma', 'TypeScript'];
const ALL_INTERESTS = ['Web Development', 'Mobile Apps', 'Data Science', 'Design', 'Backend', 'Frontend', 'Marketing', 'Cloud', 'AI/ML'];

export default function Profile() {
  const dispatch = useDispatch();
  const { user, loading } = useSelector(s => s.auth);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: '', bio: '', goals: '', skills: [], interests: [] });

  useEffect(() => {
    if (user) setForm({ name: user.name, bio: user.bio || '', goals: user.goals || '', skills: user.skills || [], interests: user.interests || [] });
  }, [user]);

  const toggleItem = (key, val) => {
    setForm(p => ({
      ...p,
      [key]: p[key].includes(val.toLowerCase()) ? p[key].filter(x => x !== val.toLowerCase()) : [...p[key], val.toLowerCase()]
    }));
  };

  const handleSave = async () => {
    const res = await dispatch(updateProfile(form));
    if (res.meta.requestStatus === 'fulfilled') {
      toast.success('Profile updated!');
      setEditing(false);
    }
  };

  if (!user) return null;

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="font-display font-bold text-3xl text-slate-900 dark:text-white">My Profile</h1>
      </motion.div>

      {/* Profile card */}
      <div className="card p-6">
        <div className="flex items-start gap-5 mb-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-white font-display font-bold text-2xl flex-shrink-0">
            {getInitials(user.name)}
          </div>
          <div className="flex-1">
            {editing ? (
              <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className="input mb-2 text-lg font-semibold" />
            ) : (
              <h2 className="font-display font-bold text-xl text-slate-900 dark:text-white">{user.name}</h2>
            )}
            <p className="text-sm text-slate-500">{user.email}</p>
            <span className="badge bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 mt-2 capitalize">{user.role}</span>
          </div>
          <button onClick={() => editing ? handleSave() : setEditing(true)}
            className={editing ? 'btn-primary flex items-center gap-2' : 'btn-secondary flex items-center gap-2'}>
            {editing ? <><MdSave size={16} /> {loading ? 'Saving...' : 'Save'}</> : <><MdEdit size={16} /> Edit</>}
          </button>
        </div>

        {/* Profile completion */}
        <div className="mb-6 p-4 bg-slate-50 dark:bg-slate-800 rounded-xl">
          <div className="flex justify-between text-sm mb-2">
            <span className="font-medium text-slate-700 dark:text-slate-300">Profile Completion</span>
            <span className="font-bold text-brand-600">{user.profileCompletion}%</span>
          </div>
          <ProgressBar value={user.profileCompletion} size="md" showLabel={false} />
        </div>

        <div className="space-y-5">
          {/* Bio */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 block mb-2">About Me</label>
            {editing
              ? <textarea value={form.bio} onChange={e => setForm(p => ({ ...p, bio: e.target.value }))} rows={3} className="input resize-none" placeholder="Tell us about yourself..." />
              : <p className="text-sm text-slate-600 dark:text-slate-400">{user.bio || 'No bio added yet.'}</p>
            }
          </div>

          {/* Goals */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 block mb-2">Career Goals</label>
            {editing
              ? <input value={form.goals} onChange={e => setForm(p => ({ ...p, goals: e.target.value }))} className="input" placeholder="e.g. Become a full-stack developer by 2026..." />
              : <p className="text-sm text-slate-600 dark:text-slate-400">{user.goals || 'No goals added yet.'}</p>
            }
          </div>

          {/* Skills */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 block mb-2">Skills</label>
            <div className="flex flex-wrap gap-2">
              {editing
                ? ALL_SKILLS.map(s => (
                  <button key={s} type="button" onClick={() => toggleItem('skills', s)}
                    className={`badge cursor-pointer transition-all text-xs ${form.skills.includes(s.toLowerCase()) ? 'bg-brand-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}>
                    {s}
                  </button>
                ))
                : user.skills?.map(s => <span key={s} className="badge bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 text-xs">{s}</span>)
              }
            </div>
          </div>

          {/* Interests */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 block mb-2">Interests</label>
            <div className="flex flex-wrap gap-2">
              {editing
                ? ALL_INTERESTS.map(s => (
                  <button key={s} type="button" onClick={() => toggleItem('interests', s)}
                    className={`badge cursor-pointer transition-all text-xs ${form.interests.includes(s.toLowerCase()) ? 'bg-purple-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}>
                    {s}
                  </button>
                ))
                : user.interests?.map(s => <span key={s} className="badge bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 text-xs">{s}</span>)
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}