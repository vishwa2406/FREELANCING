import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { MdMenuBook, MdCheckCircle, MdTrendingUp, MdWork, MdArrowForward } from 'react-icons/md';
import { fetchRecommended } from '../store/courseSlice';
import { fetchRecommendedJobs } from '../store/jobSlice';
import StatsCard from '../components/dashboard/StatsCard';
import CourseCard from '../components/courses/CourseCard';
import ProgressBar from '../components/common/ProgressBar';
import api from '../utils/api';

const progressData = [
  { name: 'Jan', hours: 4 }, { name: 'Feb', hours: 8 }, { name: 'Mar', hours: 6 },
  { name: 'Apr', hours: 14 }, { name: 'May', hours: 10 }, { name: 'Jun', hours: 18 },
];

export default function Dashboard() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector(s => s.auth);
  const { recommended } = useSelector(s => s.courses);
  const { recommended: recJobs } = useSelector(s => s.jobs);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    dispatch(fetchRecommended());
    dispatch(fetchRecommendedJobs());
    api.get('/progress/stats').then(r => setStats(r.data.stats));
  }, []);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* Welcome */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display font-bold text-3xl text-slate-900 dark:text-white">
          Welcome back, {user?.name?.split(' ')[0]} 👋
        </h1>
        <p className="text-slate-500 mt-1">Here's your learning progress at a glance</p>
      </motion.div>

      {/* Profile completion banner */}
      {user?.profileCompletion < 80 && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}
          className="card p-5 border-l-4 border-l-brand-500 flex items-center justify-between gap-4">
          <div className="flex-1">
            <p className="font-medium text-slate-900 dark:text-white text-sm mb-2">Complete your profile to get better recommendations</p>
            <ProgressBar value={user?.profileCompletion || 0} size="md" />
          </div>
          <button onClick={() => navigate('/profile')} className="btn-primary text-sm whitespace-nowrap">
            Complete Profile
          </button>
        </motion.div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard icon={MdMenuBook} label="Enrolled Courses" value={stats?.total || 0} color="brand" index={0} />
        <StatsCard icon={MdCheckCircle} label="Completed" value={stats?.completed || 0} color="green" index={1} />
        <StatsCard icon={MdTrendingUp} label="Avg Progress" value={`${stats?.avgPercentage || 0}%`} color="amber" index={2} />
        <StatsCard icon={MdWork} label="Jobs Saved" value={user?.savedJobs?.length || 0} color="rose" index={3} />
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Learning hours chart */}
        <div className="lg:col-span-2 card p-6">
          <h2 className="font-display font-semibold text-slate-900 dark:text-white mb-1">Learning Activity</h2>
          <p className="text-xs text-slate-500 mb-4">Hours spent learning per month</p>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={progressData}>
              <defs>
                <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip contentStyle={{ background: '#1e293b', border: 'none', borderRadius: 12, color: '#f1f5f9', fontSize: 12 }} />
              <Area type="monotone" dataKey="hours" stroke="#6366f1" strokeWidth={2.5} fill="url(#grad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Course breakdown */}
        <div className="card p-6">
          <h2 className="font-display font-semibold text-slate-900 dark:text-white mb-1">Course Status</h2>
          <p className="text-xs text-slate-500 mb-4">Your enrollment breakdown</p>
          <div className="flex justify-center mb-4">
            <PieChart width={140} height={140}>
              <Pie data={[
                { name: 'Completed', value: stats?.completed || 0 },
                { name: 'In Progress', value: stats?.inProgress || 0 },
                { name: 'Not Started', value: Math.max(0, (stats?.total || 0) - (stats?.completed || 0) - (stats?.inProgress || 0)) },
              ]} cx={65} cy={65} innerRadius={40} outerRadius={65} paddingAngle={3}>
                {['#6366f1', '#f59e0b', '#e2e8f0'].map((c, i) => <Cell key={i} fill={c} />)}
              </Pie>
            </PieChart>
          </div>
          <div className="space-y-2 text-sm">
            {[['Completed', stats?.completed || 0, '#6366f1'], ['In Progress', stats?.inProgress || 0, '#f59e0b'], ['Not Started', 0, '#e2e8f0']].map(([l, v, c]) => (
              <div key={l} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: c }} />
                  <span className="text-slate-600 dark:text-slate-400">{l}</span>
                </div>
                <span className="font-medium text-slate-900 dark:text-white">{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* In-progress courses */}
      {stats?.progress?.filter(p => !p.isCompleted && p.percentage > 0).length > 0 && (
        <div>
          <h2 className="font-display font-semibold text-xl text-slate-900 dark:text-white mb-4">Continue Learning</h2>
          <div className="space-y-3">
            {stats.progress.filter(p => !p.isCompleted && p.percentage > 0).map(p => (
              <div key={p._id} className="card p-4 flex items-center gap-4 cursor-pointer hover:border-brand-300 transition-all"
                onClick={() => navigate(`/courses/${p.course._id}`)}>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center flex-shrink-0">
                  <MdMenuBook size={22} className="text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-slate-900 dark:text-white text-sm truncate">{p.course.title}</p>
                  <ProgressBar value={p.percentage} size="sm" showLabel={false} />
                </div>
                <span className="text-sm font-medium text-brand-600 dark:text-brand-400">{p.percentage}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommended Courses */}
      {recommended.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-display font-semibold text-xl text-slate-900 dark:text-white">Recommended for You</h2>
              <p className="text-xs text-slate-500 mt-0.5">Based on your skills and interests</p>
            </div>
            <button onClick={() => navigate('/courses')} className="btn-ghost text-sm flex items-center gap-1">
              View All <MdArrowForward size={16} />
            </button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {recommended.slice(0, 4).map((c, i) => <CourseCard key={c._id} course={c} index={i} />)}
          </div>
        </div>
      )}

      {/* Recommended Jobs */}
      {recJobs.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-xl text-slate-900 dark:text-white">Jobs Matching Your Skills</h2>
            <button onClick={() => navigate('/jobs')} className="btn-ghost text-sm flex items-center gap-1">
              View All <MdArrowForward size={16} />
            </button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {recJobs.slice(0, 4).map((job, i) => (
              <div key={job._id} className="card p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold flex-shrink-0">
                  {job.company[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm text-slate-900 dark:text-white truncate">{job.title}</p>
                  <p className="text-xs text-slate-500">{job.company} · {job.location}</p>
                </div>
                <a href={job.applyUrl} target="_blank" rel="noreferrer" className="btn-secondary text-xs px-3 py-1.5">Apply</a>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}