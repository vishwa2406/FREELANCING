import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MdPlayCircle, MdLock, MdStar, MdPeople, MdAccessTime, MdCheckCircle, MdArrowBack } from 'react-icons/md';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCourse } from '../store/courseSlice';
import { levelColor } from '../utils/helpers';
import ProgressBar from '../components/common/ProgressBar';

export default function CourseDetail() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { current, loading } = useSelector(s => s.courses);

  useEffect(() => { dispatch(fetchCourse(id)); }, [id]);

  if (loading || !current) return (
    <div className="p-6 max-w-5xl mx-auto space-y-4">
      <div className="skeleton h-10 w-64" />
      <div className="skeleton h-56 w-full" />
    </div>
  );

  const { course, lessons, progress } = current;

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <button onClick={() => navigate(-1)} className="btn-ghost flex items-center gap-2 text-sm">
        <MdArrowBack size={18} /> Back to Courses
      </button>

      {/* Hero */}
      <div className="card overflow-hidden">
        <div className="h-48 bg-gradient-to-br from-brand-500 via-brand-600 to-purple-700 relative flex items-end p-6">
          <div>
            <span className={`badge ${levelColor(course.level)} mb-3 text-xs`}>{course.level}</span>
            <h1 className="font-display font-bold text-2xl text-white">{course.title}</h1>
            <p className="text-brand-100 mt-1 text-sm">{course.instructor}</p>
          </div>
        </div>
        <div className="p-6">
          <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed mb-4">{course.description}</p>

          <div className="flex flex-wrap gap-4 text-sm text-slate-600 dark:text-slate-400 mb-4">
            <span className="flex items-center gap-1"><MdStar className="text-amber-400" /> {course.rating} rating</span>
            <span className="flex items-center gap-1"><MdPeople /> {course.enrolledCount?.toLocaleString()} enrolled</span>
            <span className="flex items-center gap-1"><MdAccessTime /> {course.estimatedHours} hours</span>
          </div>

          {progress && <ProgressBar value={progress.percentage} size="md" />}

          <div className="flex flex-wrap gap-2 mt-4">
            {course.tags?.map(t => <span key={t} className="badge bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs">{t}</span>)}
          </div>
        </div>
      </div>

      {/* Outcomes */}
      {course.outcomes?.length > 0 && (
        <div className="card p-6">
          <h2 className="font-display font-semibold text-slate-900 dark:text-white mb-4">What you'll learn</h2>
          <div className="grid sm:grid-cols-2 gap-2">
            {course.outcomes.map((o, i) => (
              <div key={i} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-400">
                <MdCheckCircle size={18} className="text-emerald-500 flex-shrink-0 mt-0.5" />
                {o}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Lessons */}
      <div className="card p-6">
        <h2 className="font-display font-semibold text-slate-900 dark:text-white mb-4">
          Course Content · {lessons?.length} lessons
        </h2>
        <div className="space-y-2">
          {lessons?.map((lesson, i) => {
            const isCompleted = progress?.completedLessons?.includes(lesson._id);
            return (
              <motion.div key={lesson._id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                onClick={() => navigate(`/lessons/${lesson._id}`)}
                className="flex items-center gap-4 p-3.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer group transition-all">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${isCompleted ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-brand-50 dark:bg-brand-900/20'}`}>
                  {isCompleted
                    ? <MdCheckCircle size={20} className="text-emerald-500" />
                    : <MdPlayCircle size={20} className="text-brand-500" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{lesson.title}</p>
                  <p className="text-xs text-slate-500">{lesson.duration} min</p>
                </div>
                {lesson.isPreview && <span className="badge bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400 text-xs">Free Preview</span>}
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}