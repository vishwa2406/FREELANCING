import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { MdCheckCircle, MdCancel, MdArrowBack } from 'react-icons/md';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function QuizPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [result, setResult] = useState(null);
  const [current, setCurrent] = useState(0);
  const [attempts, setAttempts] = useState({ attempts: [], remaining: 3 });

  useEffect(() => {
    api.get(`/quizzes/${id}`).then(r => {
      setQuiz(r.data.quiz);
      setAnswers(new Array(r.data.quiz.questions.length).fill(-1));
    });
    api.get(`/quizzes/${id}/attempts`).then(r => setAttempts(r.data));
  }, [id]);

  const handleSubmit = async () => {
    if (answers.includes(-1)) return toast.error('Please answer all questions');
    try {
      const { data } = await api.post(`/quizzes/${id}/submit`, { answers });
      setResult(data);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Submission failed');
    }
  };

  if (!quiz) return (
    <div className="p-6 max-w-3xl mx-auto space-y-4">
      <div className="skeleton h-10 w-72" />
      <div className="skeleton h-64 w-full" />
    </div>
  );

  if (result) return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
      className="p-6 max-w-3xl mx-auto space-y-6">
      <div className={`card p-8 text-center border-2 ${result.passed ? 'border-emerald-500' : 'border-rose-500'}`}>
        <div className={`w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center ${result.passed ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
          {result.passed ? <MdCheckCircle size={40} /> : <MdCancel size={40} />}
        </div>
        <h2 className="font-display font-bold text-2xl text-slate-900 dark:text-white mb-1">
          {result.passed ? '🎉 Passed!' : 'Better luck next time'}
        </h2>
        <p className="text-slate-500 mb-4">Score: {result.score}/{result.totalQuestions} · {result.percentage}%</p>
        <div className="flex gap-3 justify-center">
          <button onClick={() => navigate(-1)} className="btn-secondary">Back to Lesson</button>
          {!result.passed && attempts.remaining > 0 && (
            <button onClick={() => { setResult(null); setAnswers(new Array(quiz.questions.length).fill(-1)); setCurrent(0); }} className="btn-primary">
              Try Again ({attempts.remaining} left)
            </button>
          )}
        </div>
      </div>

      {/* Result breakdown */}
      <div className="space-y-3">
        {result.results.map((r, i) => (
          <div key={i} className={`card p-4 border-l-4 ${r.isCorrect ? 'border-l-emerald-500' : 'border-l-rose-500'}`}>
            <p className="font-medium text-slate-900 dark:text-white text-sm mb-2">Q{i + 1}. {r.question}</p>
            <p className={`text-xs ${r.isCorrect ? 'text-emerald-600' : 'text-rose-600'}`}>
              {r.isCorrect ? '✓ Correct' : `✗ Wrong — Correct: ${quiz.questions[i]?.options?.[r.correctAnswer]}`}
            </p>
            {r.explanation && <p className="text-xs text-slate-500 mt-1">{r.explanation}</p>}
          </div>
        ))}
      </div>
    </motion.div>
  );

  const q = quiz.questions[current];

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <button onClick={() => navigate(-1)} className="btn-ghost flex items-center gap-2 text-sm">
        <MdArrowBack size={18} /> Exit Quiz
      </button>

      {/* Progress */}
      <div>
        <div className="flex justify-between text-sm text-slate-600 dark:text-slate-400 mb-2">
          <span className="font-display font-semibold text-slate-900 dark:text-white">{quiz.title}</span>
          <span>Question {current + 1} of {quiz.questions.length}</span>
        </div>
        <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
          <motion.div animate={{ width: `${((current + 1) / quiz.questions.length) * 100}%` }}
            className="h-full bg-gradient-to-r from-brand-500 to-brand-400 rounded-full" />
        </div>
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div key={current} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
          className="card p-6 space-y-4">
          <p className="font-display font-semibold text-lg text-slate-900 dark:text-white">{q.question}</p>
          <div className="space-y-2">
            {q.options.map((opt, oi) => (
              <button key={oi} onClick={() => setAnswers(a => { const n = [...a]; n[current] = oi; return n; })}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all text-sm ${answers[current] === oi
                  ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-300'
                  : 'border-slate-200 dark:border-slate-700 hover:border-brand-300 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                <span className="font-medium mr-3">{String.fromCharCode(65 + oi)}.</span>{opt}
              </button>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between">
        <button onClick={() => setCurrent(p => p - 1)} disabled={current === 0} className="btn-secondary">Previous</button>
        {current < quiz.questions.length - 1
          ? <button onClick={() => setCurrent(p => p + 1)} disabled={answers[current] === -1} className="btn-primary">Next</button>
          : <button onClick={handleSubmit} className="btn-primary">Submit Quiz</button>
        }
      </div>
    </div>
  );
}