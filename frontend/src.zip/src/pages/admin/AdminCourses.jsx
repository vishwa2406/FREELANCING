import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import { MdAdd, MdEdit, MdDelete } from 'react-icons/md';
import { fetchCourses } from '../../store/courseSlice';
import api from '../../utils/api';
import toast from 'react-hot-toast';

const emptyForm = { title: '', description: '', instructor: '', level: 'beginner', category: 'Web Development', tags: '', estimatedHours: 10, status: 'published', isFeatured: false };

export default function AdminCourses() {
  const dispatch = useDispatch();
  const { list, loading } = useSelector(s => s.courses);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);

  useEffect(() => { dispatch(fetchCourses({ limit: 50 })); }, []);

  const openCreate = () => { setEditing(null); setForm(emptyForm); setModal(true); };
  const openEdit = (c) => { setEditing(c._id); setForm({ ...c, tags: c.tags?.join(', ') || '' }); setModal(true); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = { ...form, tags: form.tags.split(',').map(t => t.trim()).filter(Boolean) };
    try {
      if (editing) { await api.patch(`/courses/${editing}`, payload); toast.success('Course updated!'); }
      else { await api.post('/courses', payload); toast.success('Course created!'); }
      setModal(false);
      dispatch(fetchCourses({ limit: 50 }));
    } catch (err) { toast.error(err.response?.data?.message || 'Error'); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this course?')) return;
    await api.delete(`/courses/${id}`);
    toast.success('Course deleted');
    dispatch(fetchCourses({ limit: 50 }));
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display font-bold text-3xl text-slate-900 dark:text-white">Manage Courses</h1>
        <button onClick={openCreate} className="btn-primary flex items-center gap-2"><MdAdd size={20} /> Add Course</button>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 dark:bg-slate-800">
            <tr>
              {['Title', 'Level', 'Category', 'Enrolled', 'Status', 'Actions'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {list.map(c => (
              <tr key={c._id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                <td className="px-4 py-3">
                  <p className="font-medium text-slate-900 dark:text-white truncate max-w-48">{c.title}</p>
                  <p className="text-xs text-slate-500">{c.instructor}</p>
                </td>
                <td className="px-4 py-3 capitalize text-slate-600 dark:text-slate-400">{c.level}</td>
                <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{c.category}</td>
                <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{c.enrolledCount}</td>
                <td className="px-4 py-3">
                  <span className={`badge text-xs ${c.status === 'published' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>{c.status}</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(c)} className="p-1.5 text-brand-600 hover:bg-brand-50 rounded-lg transition-all"><MdEdit size={16} /></button>
                    <button onClick={() => handleDelete(c._id)} className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-all"><MdDelete size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {modal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className="bg-white dark:bg-slate-900 rounded-2xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="font-display font-semibold text-lg text-slate-900 dark:text-white mb-4">{editing ? 'Edit Course' : 'New Course'}</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="Course Title" className="input" required />
              <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="Description" className="input resize-none" rows={3} required />
              <input value={form.instructor} onChange={e => setForm(p => ({ ...p, instructor: e.target.value }))} placeholder="Instructor Name" className="input" required />
              <div className="grid grid-cols-2 gap-3">
                <select value={form.level} onChange={e => setForm(p => ({ ...p, level: e.target.value }))} className="input">
                  {['beginner', 'intermediate', 'advanced'].map(l => <option key={l} value={l}>{l}</option>)}
                </select>
                <input value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} placeholder="Category" className="input" />
              </div>
              <input value={form.tags} onChange={e => setForm(p => ({ ...p, tags: e.target.value }))} placeholder="Tags (comma-separated): react, javascript" className="input" />
              <div className="grid grid-cols-2 gap-3">
                <input type="number" value={form.estimatedHours} onChange={e => setForm(p => ({ ...p, estimatedHours: Number(e.target.value) }))} placeholder="Hours" className="input" />
                <select value={form.status} onChange={e => setForm(p => ({ ...p, status: e.target.value }))} className="input">
                  <option value="published">Published</option>
                  <option value="draft">Draft</option>
                </select>
              </div>
              <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                <input type="checkbox" checked={form.isFeatured} onChange={e => setForm(p => ({ ...p, isFeatured: e.target.checked }))} className="rounded" />
                Featured Course
              </label>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setModal(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" className="btn-primary flex-1">{editing ? 'Update' : 'Create'}</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}