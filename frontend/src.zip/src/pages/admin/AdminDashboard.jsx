import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { MdPeople, MdMenuBook, MdWork, MdTrendingUp } from 'react-icons/md';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import api from '../../utils/api';
import StatsCard from '../../components/dashboard/StatsCard';
import { formatDate } from '../../utils/helpers';

export default function AdminDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    api.get('/admin/analytics').then(r => setData(r.data.analytics));
  }, []);

  if (!data) return <div className="p-6"><div className="skeleton h-64 w-full" /></div>;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="font-display font-bold text-3xl text-slate-900 dark:text-white">Admin Dashboard</h1>
        <p className="text-slate-500 mt-1">Platform overview and analytics</p>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard icon={MdPeople} label="Total Users" value={data.totalUsers} color="brand" index={0} />
        <StatsCard icon={MdMenuBook} label="Live Courses" value={data.totalCourses} color="green" index={1} />
        <StatsCard icon={MdWork} label="Active Jobs" value={data.totalJobs} color="amber" index={2} />
        <StatsCard icon={MdTrendingUp} label="Enrollments" value={data.totalEnrollments} color="rose" index={3} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Top courses */}
        <div className="card p-6">
          <h2 className="font-display font-semibold text-slate-900 dark:text-white mb-4">Top Courses by Enrollment</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={data.topCourses} layout="vertical">
              <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="title" tick={{ fontSize: 10, fill: '#94a3b8' }} width={120} axisLine={false} tickLine={false} tickFormatter={v => v.length > 18 ? v.slice(0, 18) + '...' : v} />
              <Tooltip contentStyle={{ background: '#1e293b', border: 'none', borderRadius: 12, color: '#f1f5f9', fontSize: 12 }} />
              <Bar dataKey="enrolledCount" fill="#6366f1" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent users */}
        <div className="card p-6">
          <h2 className="font-display font-semibold text-slate-900 dark:text-white mb-4">Recent Registrations</h2>
          <div className="space-y-3">
            {data.recentUsers.map(u => (
              <div key={u._id} className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white text-xs font-bold">
                  {u.name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{u.name}</p>
                  <p className="text-xs text-slate-500">{u.email}</p>
                </div>
                <span className="text-xs text-slate-400">{formatDate(u.createdAt)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}