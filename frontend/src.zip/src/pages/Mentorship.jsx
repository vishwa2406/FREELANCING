import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { MdStar, MdSend } from 'react-icons/md';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { getInitials } from '../utils/helpers';

export default function Mentorship() {
  const [mentors, setMentors] = useState([]);
  const [myRequests, setMyRequests] = useState([]);
  const [msgModal, setMsgModal] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    api.get('/mentors').then(r => setMentors(r.data.mentors));
    api.get('/mentors/my-requests').then(r => setMyRequests(r.data.requests));
  }, []);

  const sendRequest = async () => {
    if (!message.trim()) return toast.error('Please add a message');
    try {
      await api.post('/mentors/request', { mentorId: msgModal._id, message });
      toast.success('Mentorship request sent!');
      setMsgModal(null); setMessage('');
      api.get('/mentors/my-requests').then(r => setMyRequests(r.data.requests));
    } catch (err) { toast.error(err.response?.data?.message || 'Request failed'); }
  };

  const statusColor = { pending: 'bg-amber-100 text-amber-700', accepted: 'bg-emerald-100 text-emerald-700', rejected: 'bg-rose-100 text-rose-700', completed: 'bg-blue-100 text-blue-700' };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-8">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="font-display font-bold text-3xl text-slate-900 dark:text-white">Find a Mentor</h1>
        <p className="text-slate-500 mt-1">Connect with experienced professionals</p>
      </motion.div>

      {/* Mentor grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {mentors.map((mentor, i) => (
          <motion.div key={mentor._id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
            className="card p-5 text-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-white font-display font-bold text-xl mx-auto mb-3">
              {getInitials(mentor.name)}
            </div>
            <h3 className="font-display font-semibold text-slate-900 dark:text-white">{mentor.name}</h3>
            <p className="text-xs text-slate-500 mt-1 mb-3 line-clamp-2">{mentor.bio}</p>
            <div className="flex flex-wrap gap-1 justify-center mb-4">
              {mentor.skills?.slice(0, 3).map(s => (
                <span key={s} className="badge bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 text-xs">{s}</span>
              ))}
            </div>
            <button onClick={() => setMsgModal(mentor)} className="btn-primary w-full text-sm">Request Mentorship</button>
          </motion.div>
        ))}
      </div>

      {/* My Requests */}
      {myRequests.length > 0 && (
        <div>
          <h2 className="font-display font-semibold text-xl text-slate-900 dark:text-white mb-4">My Requests</h2>
          <div className="space-y-3">
            {myRequests.map(req => (
              <div key={req._id} className="card p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-brand-500 flex items-center justify-center text-white font-bold flex-shrink-0">
                  {getInitials(req.mentor?.name)}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-sm text-slate-900 dark:text-white">{req.mentor?.name}</p>
                  <p className="text-xs text-slate-500">{req.message}</p>
                </div>
                <span className={`badge ${statusColor[req.status]} text-xs`}>{req.status}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Request modal */}
      {msgModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className="bg-white dark:bg-slate-900 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="font-display font-semibold text-lg text-slate-900 dark:text-white mb-1">Request Mentorship</h3>
            <p className="text-sm text-slate-500 mb-4">from {msgModal.name}</p>
            <textarea value={message} onChange={e => setMessage(e.target.value)}
              rows={4} placeholder="Introduce yourself and describe what you'd like help with..."
              className="input resize-none mb-4" />
            <div className="flex gap-3">
              <button onClick={() => setMsgModal(null)} className="btn-secondary flex-1">Cancel</button>
              <button onClick={sendRequest} className="btn-primary flex-1 flex items-center justify-center gap-2">
                <MdSend size={16} /> Send Request
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}