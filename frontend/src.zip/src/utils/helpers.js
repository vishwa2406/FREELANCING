export const formatDate = (date) => new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

export const levelColor = (level) => ({
  beginner: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  intermediate: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
  advanced: 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400',
}[level] || 'bg-slate-100 text-slate-600');

export const jobTypeColor = (type) => ({
  'full-time': 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  'part-time': 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
  'internship': 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  'remote': 'bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400',
  'freelance': 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
}[type] || 'bg-slate-100 text-slate-600');

export const truncate = (str, n) => str?.length > n ? str.slice(0, n) + '...' : str;

export const getInitials = (name) => name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);