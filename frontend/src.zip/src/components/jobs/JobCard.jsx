import { motion } from 'framer-motion';
import { MdLocationOn, MdBookmark, MdBookmarkBorder, MdArrowForward } from 'react-icons/md';
import { jobTypeColor, formatDate } from '../../utils/helpers';
import api from '../../utils/api';
import toast from 'react-hot-toast';
import { useSelector } from 'react-redux';

export default function JobCard({ job, index = 0 }) {
  const { user } = useSelector(s => s.auth);
  const isSaved = user?.savedJobs?.includes(job._id);

  const handleSave = async (e) => {
    e.stopPropagation();
    try {
      await api.post(`/jobs/${job._id}/save`);
      toast.success(isSaved ? 'Job removed' : 'Job saved!');
    } catch { toast.error('Please login to save jobs'); }
  };

  const companyInitial = job.company[0].toUpperCase();
  const colors = ['bg-violet-500', 'bg-blue-500', 'bg-emerald-500', 'bg-rose-500', 'bg-amber-500'];
  const color = colors[job.company.length % colors.length];

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.04 }}
      className="card p-5 hover:border-brand-300 dark:hover:border-brand-700 transition-all group">
      <div className="flex items-start gap-4">
        {/* Logo */}
        <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center text-white font-display font-bold text-lg flex-shrink-0`}>
          {companyInitial}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="font-display font-semibold text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                {job.title}
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">{job.company}</p>
            </div>
            <button onClick={handleSave} className="text-slate-400 hover:text-brand-500 transition-colors flex-shrink-0 mt-0.5">
              {isSaved ? <MdBookmark size={20} className="text-brand-500" /> : <MdBookmarkBorder size={20} />}
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2 mt-2">
            <span className={`badge ${jobTypeColor(job.type)}`}>{job.type}</span>
            <span className="text-xs text-slate-500 flex items-center gap-1"><MdLocationOn size={13} />{job.location}</span>
            <span className="text-xs text-slate-500">💰 {job.salary}</span>
          </div>

          <div className="flex flex-wrap gap-1.5 mt-3">
            {job.skills?.slice(0, 4).map(s => (
              <span key={s} className="badge bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs">{s}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
        <span className="text-xs text-slate-400">Posted {formatDate(job.createdAt)}</span>
        <a href={job.applyUrl} target="_blank" rel="noreferrer"
          className="flex items-center gap-1 text-sm text-brand-600 dark:text-brand-400 font-medium hover:gap-2 transition-all">
          Apply Now <MdArrowForward size={16} />
        </a>
      </div>
    </motion.div>
  );
}