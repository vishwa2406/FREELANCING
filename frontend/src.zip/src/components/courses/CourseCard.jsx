import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MdBookmark, MdBookmarkBorder, MdStar, MdAccessTime, MdPeople } from 'react-icons/md';
import { useSelector } from 'react-redux';
import { levelColor, truncate } from '../../utils/helpers';
import api from '../../utils/api';
import toast from 'react-hot-toast';

export default function CourseCard({ course, progress, index = 0 }) {
  const navigate = useNavigate();
  const { user } = useSelector(s => s.auth);
  const isBookmarked = user?.bookmarkedCourses?.includes(course._id);

  const handleBookmark = async (e) => {
    e.stopPropagation();
    try {
      await api.post(`/courses/${course._id}/bookmark`);
      toast.success(isBookmarked ? 'Bookmark removed' : 'Course bookmarked!');
    } catch { toast.error('Please login to bookmark'); }
  };

  const coverColors = ['from-violet-500 to-purple-600', 'from-blue-500 to-cyan-600', 'from-emerald-500 to-teal-600', 'from-rose-500 to-pink-600', 'from-amber-500 to-orange-600', 'from-indigo-500 to-blue-600'];
  const color = coverColors[index % coverColors.length];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ y: -4 }}
      onClick={() => navigate(`/courses/${course._id}`)}
      className="card overflow-hidden cursor-pointer group"
    >
      {/* Thumbnail */}
      <div className={`relative h-44 bg-gradient-to-br ${color} flex items-end p-4`}>
        {course.isFeatured && (
          <span className="absolute top-3 left-3 badge bg-white/20 text-white backdrop-blur-sm">⭐ Featured</span>
        )}
        <button onClick={handleBookmark} className="absolute top-3 right-3 w-8 h-8 bg-white/20 hover:bg-white/40 backdrop-blur-sm rounded-full flex items-center justify-center text-white transition-all">
          {isBookmarked ? <MdBookmark size={18} /> : <MdBookmarkBorder size={18} />}
        </button>
        <span className={`badge ${levelColor(course.level)} text-xs`}>{course.level}</span>
      </div>

      {/* Content */}
      <div className="p-5">
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-1.5">{course.category}</p>
        <h3 className="font-display font-semibold text-slate-900 dark:text-white text-sm leading-snug mb-2 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors line-clamp-2">
          {course.title}
        </h3>
        <p className="text-xs text-slate-500 mb-3 line-clamp-2">{course.description}</p>

        <div className="flex items-center gap-3 text-xs text-slate-500 mb-3">
          <span className="flex items-center gap-1"><MdStar className="text-amber-400" /> {course.rating}</span>
          <span className="flex items-center gap-1"><MdPeople /> {course.enrolledCount?.toLocaleString()}</span>
          <span className="flex items-center gap-1"><MdAccessTime /> {course.estimatedHours}h</span>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-4">
          {course.tags?.slice(0, 3).map(tag => (
            <span key={tag} className="badge bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs">{tag}</span>
          ))}
        </div>

        {/* Progress bar if enrolled */}
        {progress !== undefined && (
          <div className="mb-3">
            <div className="flex justify-between text-xs text-slate-500 mb-1">
              <span>Progress</span><span>{progress}%</span>
            </div>
            <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }} animate={{ width: `${progress}%` }}
                transition={{ duration: 0.8, delay: index * 0.05 }}
                className="h-full bg-gradient-to-r from-brand-500 to-brand-400 rounded-full"
              />
            </div>
          </div>
        )}

        <button className="btn-primary w-full text-sm">
          {progress !== undefined ? (progress === 100 ? 'Review Course' : 'Continue Learning') : 'Start Learning'}
        </button>
      </div>
    </motion.div>
  );
}