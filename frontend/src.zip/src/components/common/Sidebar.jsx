import { NavLink, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { motion, AnimatePresence } from 'framer-motion';
import { logout } from '../../store/authSlice';
import { toggleDarkMode } from '../../store/uiSlice';
import { getInitials } from '../../utils/helpers';
import {
  MdDashboard, MdMenuBook, MdWork, MdPeople, MdPerson,
  MdAdminPanelSettings, MdLightMode, MdDarkMode, MdLogout, MdClose
} from 'react-icons/md';

const navItems = [
  { to: '/dashboard', icon: MdDashboard, label: 'Dashboard' },
  { to: '/courses', icon: MdMenuBook, label: 'Courses' },
  { to: '/jobs', icon: MdWork, label: 'Jobs' },
  { to: '/mentorship', icon: MdPeople, label: 'Mentorship' },
  { to: '/profile', icon: MdPerson, label: 'Profile' },
];

const adminItems = [
  { to: '/admin', icon: MdAdminPanelSettings, label: 'Admin Panel' },
];

export default function Sidebar({ open, onClose }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector(s => s.auth);
  const { darkMode } = useSelector(s => s.ui);

  const handleLogout = () => { dispatch(logout()); navigate('/'); };

  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={onClose} />
        )}
      </AnimatePresence>

      <motion.aside
        initial={false}
        animate={{ x: open ? 0 : -280 }}
        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
        className="fixed left-0 top-0 h-full w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 z-40 flex flex-col lg:translate-x-0"
      >
        {/* Logo */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center">
              <span className="text-white font-display font-bold text-sm">CG</span>
            </div>
            <div>
              <p className="font-display font-bold text-sm text-slate-900 dark:text-white">CEGP</p>
              <p className="text-xs text-slate-500">Career Portal</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden btn-ghost p-2"><MdClose size={20} /></button>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink key={to} to={to} onClick={onClose}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <Icon size={20} />
              <span className="text-sm">{label}</span>
            </NavLink>
          ))}
          {user?.role === 'admin' && (
            <>
              <div className="pt-3 pb-1">
                <p className="text-xs font-semibold text-slate-400 dark:text-slate-600 px-4 uppercase tracking-wider">Admin</p>
              </div>
              {adminItems.map(({ to, icon: Icon, label }) => (
                <NavLink key={to} to={to} onClick={onClose}
                  className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
                  <Icon size={20} />
                  <span className="text-sm">{label}</span>
                </NavLink>
              ))}
            </>
          )}
        </nav>

        {/* Bottom */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
          <button onClick={() => dispatch(toggleDarkMode())}
            className="sidebar-link w-full">
            {darkMode ? <MdLightMode size={20} /> : <MdDarkMode size={20} />}
            <span className="text-sm">{darkMode ? 'Light Mode' : 'Dark Mode'}</span>
          </button>
          {user && (
            <div className="flex items-center gap-3 px-4 py-3">
              <div className="w-8 h-8 rounded-full bg-brand-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                {getInitials(user.name)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{user.name}</p>
                <p className="text-xs text-slate-500 truncate">{user.email}</p>
              </div>
              <button onClick={handleLogout} className="text-slate-400 hover:text-rose-500 transition-colors">
                <MdLogout size={18} />
              </button>
            </div>
          )}
        </div>
      </motion.aside>
    </>
  );
}