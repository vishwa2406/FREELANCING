import { motion } from 'framer-motion';

export default function ProgressBar({ value = 0, color = 'brand', size = 'md', showLabel = true }) {
  const heights = { sm: 'h-1.5', md: 'h-2.5', lg: 'h-3.5' };
  const colors = {
    brand: 'bg-gradient-to-r from-brand-500 to-brand-400',
    green: 'bg-gradient-to-r from-emerald-500 to-teal-400',
    amber: 'bg-gradient-to-r from-amber-500 to-orange-400',
  };

  return (
    <div className="w-full">
      <div className={`w-full ${heights[size]} bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden`}>
        <motion.div
          initial={{ width: 0 }} animate={{ width: `${value}%` }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className={`h-full rounded-full ${colors[color]}`}
        />
      </div>
      {showLabel && <span className="text-xs text-slate-500 mt-1">{value}%</span>}
    </div>
  );
}