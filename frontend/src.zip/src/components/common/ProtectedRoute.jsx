import { useSelector } from 'react-redux';
import { Navigate, Outlet } from 'react-router-dom';

export function ProtectedRoute() {
  const { user, token, initialized } = useSelector(s => s.auth);
  if (!initialized) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-10 h-10 border-4 border-brand-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );
  return token && user ? <Outlet /> : <Navigate to="/login" replace />;
}

export function AdminRoute() {
  const { user, token, initialized } = useSelector(s => s.auth);
  if (!initialized) return null;
  if (!token || !user) return <Navigate to="/login" replace />;
  if (user.role !== 'admin') return <Navigate to="/dashboard" replace />;
  return <Outlet />;
}