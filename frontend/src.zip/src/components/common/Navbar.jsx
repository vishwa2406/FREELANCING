import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { MdMenu, MdNotifications, MdSearch } from 'react-icons/md';
import { setSidebar } from '../../store/uiSlice';
import { getInitials } from '../../utils/helpers';

export default function Navbar({ onMenuClick }) {
  const { user } = useSelector(s => s.auth);
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-20 h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 flex items-center px-4 lg:px-6 gap-4">
      <button onClick={onMenuClick} className="btn-ghost p-2 lg:hidden">
        <MdMenu size={22} />
      </button>

      {/* Search */}
      <div className="flex-1 max-w-md hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-transparent focus-within:border-brand-500 transition-all">
        <MdSearch size={18} className="text-slate-400" />
        <input placeholder="Search courses, jobs..." className="bg-transparent text-sm outline-none flex-1 text-slate-700 dark:text-slate-300 placeholder:text-slate-400" />
      </div>

      <div className="ml-auto flex items-center gap-3">
        <button className="relative btn-ghost p-2">
          <MdNotifications size={22} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-500 rounded-full"></span>
        </button>
        {user && (
          <button onClick={() => navigate('/profile')}
            className="w-9 h-9 rounded-full bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white text-sm font-bold">
            {getInitials(user.name)}
          </button>
        )}
      </div>
    </header>
  );
}