import { useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Toaster } from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { fetchMe } from './store/authSlice';
import Sidebar from './components/common/Sidebar';
import Navbar from './components/common/Navbar';
import { ProtectedRoute, AdminRoute } from './components/common/ProtectedRoute';
import { setSidebar } from './store/uiSlice';

// Pages
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Courses from './pages/Courses';
import CourseDetail from './pages/CourseDetail';
import LessonView from './pages/LessonView';
import Jobs from './pages/Jobs';
import Mentorship from './pages/Mentorship';
import Profile from './pages/Profile';
import QuizPage from './pages/QuizPage';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminCourses from './pages/admin/AdminCourses';
import AdminUsers from './pages/admin/AdminUsers';

const pageVariants = { initial: { opacity: 0, y: 8 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -8 } };

function AppLayout({ children }) {
  const { sidebarOpen } = useSelector(s => s.ui);
  const dispatch = useDispatch();

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950">
      <Sidebar open={sidebarOpen} onClose={() => dispatch(setSidebar(false))} />
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        <Navbar onMenuClick={() => dispatch(setSidebar(true))} />
        <main className="flex-1 overflow-auto">
          <AnimatePresence mode="wait">
            <motion.div key={window.location.pathname} {...pageVariants} transition={{ duration: 0.25 }}>
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  const dispatch = useDispatch();
  const { darkMode } = useSelector(s => s.ui);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    if (localStorage.getItem('cegp_token')) dispatch(fetchMe());
  }, []);

  return (
    <>
      <Toaster position="top-right" toastOptions={{
        style: { background: darkMode ? '#1e293b' : '#fff', color: darkMode ? '#f1f5f9' : '#0f172a', borderRadius: 12, fontSize: 14 }
      }} />
      <Routes>
        {/* Public */}
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Protected */}
        <Route element={<ProtectedRoute />}>
          <Route path="/dashboard" element={<AppLayout><Dashboard /></AppLayout>} />
          <Route path="/courses" element={<AppLayout><Courses /></AppLayout>} />
          <Route path="/courses/:id" element={<AppLayout><CourseDetail /></AppLayout>} />
          <Route path="/lessons/:id" element={<AppLayout><LessonView /></AppLayout>} />
          <Route path="/jobs" element={<AppLayout><Jobs /></AppLayout>} />
          <Route path="/mentorship" element={<AppLayout><Mentorship /></AppLayout>} />
          <Route path="/profile" element={<AppLayout><Profile /></AppLayout>} />
          <Route path="/quiz/:id" element={<AppLayout><QuizPage /></AppLayout>} />
        </Route>

        {/* Admin */}
        <Route element={<AdminRoute />}>
          <Route path="/admin" element={<AppLayout><AdminDashboard /></AppLayout>} />
          <Route path="/admin/courses" element={<AppLayout><AdminCourses /></AppLayout>} />
          <Route path="/admin/users" element={<AppLayout><AdminUsers /></AppLayout>} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}